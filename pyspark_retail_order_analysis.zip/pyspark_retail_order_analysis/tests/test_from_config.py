import os
import pytest
import json
import ast
from datetime import datetime
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col
import student_submission.solution as sol

with open("tests/test_config.json") as f:
    config = json.load(f)

GREEN = "\033[92m"
RED = "\033[91m"
RESET = "\033[0m"

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[*]").appName("RetailOrdersAnalyticsTest").getOrCreate()

def log_result(status, func_name):
    msg = f"[{status}] {func_name} at {datetime.now()}"
    with open("test_report.log", "a") as f:
        f.write(msg + "\n")
    print(f"{GREEN if 'PASS' in status else RED}{msg}{RESET}")

def annotate_ast_with_parents(node, parent=None):
    for child in ast.iter_child_nodes(node):
        child.parent = parent
        annotate_ast_with_parents(child, child)

def validate_ast_anti_cheat(func_name, fn_node):
    # Basic anti-cheat: 'pass' usage
    for node in ast.walk(fn_node):
        if isinstance(node, ast.Pass):
            raise AssertionError("Anti-cheat violation: 'pass' statement found.")

    # Hardcoded value detection
    banned_literals = ["Electronics", "New York", "Books", "Active", "John"]
    for node in ast.walk(fn_node):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value in banned_literals and not isinstance(getattr(node, "parent", None), ast.Compare):
                raise AssertionError(f"Anti-cheat violation: hardcoded value '{node.value}' used improperly")

def validate_sorting_and_limit(func_name, fn_node):
    if func_name not in ["top_customers_by_spend", "most_returned_items"]:
        return

    has_order_by = has_desc = has_limit = False

    for node in ast.walk(fn_node):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "orderBy":
                has_order_by = True
                for arg in node.args:
                    if isinstance(arg, ast.Call) and getattr(arg.func, "attr", "") == "desc":
                        has_desc = True
            elif node.func.attr == "limit":
                has_limit = True

    if not (has_order_by and has_desc and has_limit):
        raise AssertionError("Anti-cheat: Must use orderBy(desc(...)).limit(...) for top-k selection.")

@pytest.mark.parametrize("test_case", config)
def test_configurable_functions(test_case, spark, raw_orders_df, raw_returns_df):
    func_name = test_case["function"]
    args = test_case["args"]
    expected = test_case["expected"]

    arg_map = {
        "spark": spark,
        "raw_orders_df": raw_orders_df,
        "raw_returns_df": raw_returns_df,
        "orders_csv_path": "data/orders.csv",
        "returns_csv_path": "data/returns.csv",
        "2024": 2024,
        "30": 30
    }

    actual_args = [arg_map.get(arg, arg) for arg in args]

    try:
        with open("student_submission/solution.py") as f:
            src = f.read()
        tree = ast.parse(src)
        annotate_ast_with_parents(tree)

        fn_node = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == func_name), None)
        if fn_node is None:
            raise AssertionError(f"Function '{func_name}' not found in solution.py")

        validate_ast_anti_cheat(func_name, fn_node)
        validate_sorting_and_limit(func_name, fn_node)

        fn = getattr(sol, func_name)
        result = fn(*actual_args)

        # Output type checks
        if expected == "DataFrame":
            assert isinstance(result, DataFrame), "Expected a DataFrame"
            assert result.count() > 0, "Returned DataFrame is empty"
            if isinstance(actual_args[0], DataFrame) and result.collect() == actual_args[0].collect():
                raise AssertionError("Anti-cheat: Returned unmodified input DataFrame")

        elif expected == "list":
            assert isinstance(result, list), "Expected a list"
            assert len(result) > 0, "Returned empty list"

        elif expected == "tuple":
            assert isinstance(result, tuple), "Expected a tuple"
            assert isinstance(result[0], str), "First element of tuple should be string"
            assert isinstance(result[1], DataFrame), "Second element should be DataFrame"

        log_result("PASS", func_name)

    except AssertionError as ae:
        log_result(f"FAIL - {ae}", func_name)
        pytest.fail(str(ae))
    except Exception as e:
        log_result(f"FAIL - Unexpected Error: {str(e)}", func_name)
        pytest.fail(str(e))
