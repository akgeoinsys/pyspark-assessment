import json
import importlib.util
from pyspark.sql import SparkSession

# Load test config
with open("tests/test_config.json") as f:
    test_cases = json.load(f)

# Initialize Spark
spark = SparkSession.builder \
    .appName("PatientDoctorTestRunner") \
    .master("local[*]") \
    .getOrCreate()

# Load student solution
spec = importlib.util.spec_from_file_location("solution", "student_submission/solution.py")
sol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sol)

# Run each test case
for case in test_cases["tests"]:
    func = getattr(sol, case["function"])
    args = [spark if x == "spark" else x for x in case["inputs"]]
    result = func(*args)
    if isinstance(result, list):
        print(f"{case['function']} output:", result)
    else:
        result.show()
