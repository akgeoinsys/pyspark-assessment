# drivers/run_json.py
import pytest
import os

if os.path.exists("test_report.log"):
    os.remove("test_report.log")

pytest.main([
    "tests/test_from_config.py",
    "-v",
    "--tb=short",
    "--disable-warnings"
])
