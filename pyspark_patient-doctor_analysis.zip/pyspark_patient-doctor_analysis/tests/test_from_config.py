import pytest
import json
import os
from pyspark.sql import SparkSession
import solution as sol

# Read config
with open("test_config.json") as f:
    config = json.load(f)

# Spark session fixture
@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local").appName("TestPatientDoctor").getOrCreate()

# Shared DataFrames for reuse
@pytest.fixture(scope="module")
def df_patient(spark):
    return sol.create_patient_df(spark, "data/patients.csv")

@pytest.fixture(scope="module")
def df_doctor(spark):
    return sol.create_doctor_df(spark, "data/doctors.csv")

@pytest.fixture(scope="module")
def df_joined(df_patient, df_doctor):
    return sol.join_patient_doctor_df(df_patient, df_doctor)

@pytest.mark.parametrize("test_case", config["test_cases"])
def test_from_config(spark, df_patient, df_doctor, df_joined, test_case):
    func = getattr(sol, test_case["function"])
    args = []
    for arg in test_case["args"]:
        if arg == "spark":
            args.append(spark)
        elif arg == "df_patient":
            args.append(df_patient)
        elif arg == "df_doctor":
            args.append(df_doctor)
        elif arg == "df_joined":
            args.append(df_joined)
        else:
            args.append(arg)

    result_df = func(*args)

    if test_case["compare"] == "schema_only":
        assert len(result_df.columns) > 0, f"{test_case['function']} returned no columns"
    elif test_case["compare"] == "row_count":
        assert result_df.count() > 0, f"{test_case['function']} returned 0 rows"
    elif test_case["compare"] == "columns_and_row_count":
        assert result_df.count() > 0, f"{test_case['function']} returned 0 rows"
        assert len(result_df.columns) > 0, f"{test_case['function']} returned no columns"
