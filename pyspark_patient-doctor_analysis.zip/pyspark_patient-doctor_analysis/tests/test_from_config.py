import pytest
import json
import importlib.util
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Load test config
with open("tests/test_config.json") as f:
    test_cases = json.load(f)

# Load student solution
spec = importlib.util.spec_from_file_location("solution", "student_submission/solution.py")
sol = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sol)

# Setup Spark
spark = SparkSession.builder \
    .appName("TestPatientDoctor") \
    .master("local[*]") \
    .getOrCreate()

# Helper to build schema
def build_schema(schema_dict):
    fields = [StructField(f["name"], getattr(__import__("pyspark.sql.types"), f["type"])(), True) for f in schema_dict["fields"]]
    return StructType(fields)

@pytest.mark.parametrize("case", test_cases["tests"])
def test_from_config(case):
    func_name = case["function"]
    func = getattr(sol, func_name)

    args = []
    for arg in case["inputs"]:
        if arg == "spark":
            args.append(spark)
        elif isinstance(arg, dict) and arg["type"] == "StructType":
            args.append(build_schema(arg))
        else:
            args.append(arg)

    result = func(*args)
    assert result is not None
    assert hasattr(result, "show")
