from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, sum , count

# 1️⃣ Load patient dataset with user-defined schema
def create_patient_df(spark: SparkSession, patient_path: str) -> DataFrame:
    # Users are expected to define schema outside this function and pass it if needed
    

# 2️⃣ Load doctor dataset with user-defined schema
def create_doctor_df(spark: SparkSession, doctor_path: str) -> DataFrame:
   pass
# 3️⃣ Join patient and doctor data on doctor_id
def join_patient_doctor_df(patients_df: DataFrame, doctors_df: DataFrame) -> DataFrame:
   pass

# 4️⃣ Sum of units_received per doctor
def group_by_units_received_sum(df: DataFrame) -> DataFrame:
   pass

# 5️⃣ Count of patient visits per doctor
def group_by_patient_count(df: DataFrame) -> DataFrame:
  pass