##Follow the implementation flow in Readme.md 
##PRACTICE THE IMPORT , FUNCTION CREATION, METHODS .
## DONT COPY . WRITE FROM THE SCRATCH 
