from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col
import student_submission.solution as sol
import json
import pytest
from datetime import datetime
import ast

# Load test configuration
with open("tests/test_config.json") as f:
    config = json.load(f)

BANNED_LITERALS = {"Gold", "Active", "Premium", "New York", "Electronics", "Laptop"}
TOP_K_FUNCS = {"top_feedback_by_rating", "top_regions_by_refunds", "top_loyalty_customers", "rank_inventory_by_value", "top_users_by_activity"}

def annotate_ast_with_parents(node, parent=None):
    for child in ast.iter_child_nodes(node):
        child.parent = parent
        annotate_ast_with_parents(child, child)

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[*]").appName("UnifiedTest").getOrCreate()

def extract_function_node(func_name):
    with open("student_submission/solution.py", encoding="utf-8") as f:
        src = f.read()
    tree = ast.parse(src)
    annotate_ast_with_parents(tree)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            return node
    raise AssertionError(f"Function '{func_name}' not found in solution.py")

def validate_no_pass(func_node):
    for node in ast.walk(func_node):
        if isinstance(node, ast.Pass):
            raise AssertionError("Anti-cheat violation: 'pass' used in function")

def validate_no_banned_literals(func_node):
    for node in ast.walk(func_node):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value in BANNED_LITERALS:
                if not isinstance(getattr(node, "parent", None), ast.Compare):
                    raise AssertionError(f"Anti-cheat violation: banned literal '{node.value}' used")

def validate_top_k_sort_limit(func_node, func_name):
    if func_name not in TOP_K_FUNCS:
        return
    found_orderBy, found_desc, found_limit = False, False, False

    for node in ast.walk(func_node):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            attr = node.func.attr
            if attr == "orderBy":
                found_orderBy = True
                for arg in node.args:
                    if isinstance(arg, ast.Call) and getattr(arg.func, "attr", "") == "desc":
                        found_desc = True
            elif attr == "limit":
                found_limit = True

    if not (found_orderBy and found_desc and found_limit):
        raise AssertionError("Anti-cheat violation: Must use orderBy(desc(...)).limit() for top-k results")

@pytest.mark.parametrize("test_case", config)
def test_configurable_functions(test_case, spark):
    func_name = test_case["function"]
    args = test_case["args"]
    expected = test_case["expected"]

    # Load necessary DataFrames
    df_map = {
        "data/feedback.csv": spark.read.option("header", True).csv("data/feedback.csv", inferSchema=True),
        "data/catalog.json": spark.read.option("multiline", True).json("data/catalog.json"),
        "data/refund_claims.csv": spark.read.option("header", True).csv("data/refund_claims.csv", inferSchema=True),
        "data/customers.csv": spark.read.option("header", True).csv("data/customers.csv", inferSchema=True),
        "data/loyalty_programs.csv": spark.read.option("header", True).csv("data/loyalty_programs.csv", inferSchema=True),
        "data/inventory.csv": spark.read.option("header", True).csv("data/inventory.csv", inferSchema=True),
        "data/user_profiles.csv": spark.read.option("header", True).csv("data/user_profiles.csv", inferSchema=True)
    }

    arg_map = {"spark": spark}
    arg_map.update(df_map)

    try:
        if "feedback_df" in args:
            arg_map["feedback_df"] = sol.load_feedback_from_csv(spark, "data/feedback.csv")
        if "claims_df" in args:
            arg_map["claims_df"] = sol.load_refund_claims(spark, "data/refund_claims.csv")
        if "customers_df" in args:
            arg_map["customers_df"] = sol.load_customer_enrollments(spark, "data/customers.csv")
        if "programs_df" in args:
            arg_map["programs_df"] = sol.load_loyalty_programs(spark, "data/loyalty_programs.csv")
        if "enrollment_df" in args:
            c = sol.load_customer_enrollments(spark, "data/customers.csv")
            p = sol.load_loyalty_programs(spark, "data/loyalty_programs.csv")
            arg_map["enrollment_df"] = sol.join_customers_with_loyalty_programs(c, p)
        if "inventory_df" in args:
            arg_map["inventory_df"] = sol.load_inventory_data(spark, "data/inventory.csv")
        if "profiles_df" in args:
            arg_map["profiles_df"] = sol.load_user_profiles(spark, "data/user_profiles.csv")
    except Exception as e:
        pytest.fail(f"Setup failed: {e}")

    actual_args = [arg_map.get(arg, arg) for arg in args]

    try:
        func_node = extract_function_node(func_name)
        validate_no_pass(func_node)
        validate_no_banned_literals(func_node)
        validate_top_k_sort_limit(func_node, func_name)

        fn = getattr(sol, func_name)
        result = fn(*actual_args)

        if expected == "DataFrame":
            assert isinstance(result, DataFrame), f"Expected DataFrame, got {type(result)}"
            assert result.count() > 0, f"Returned empty DataFrame for {func_name}"
            if isinstance(actual_args[0], DataFrame) and result.collect() == actual_args[0].collect():
                raise AssertionError("Anti-cheat violation: returned input DataFrame unchanged")
        elif expected == "list":
            assert isinstance(result, list), f"Expected list, got {type(result)}"
            assert len(result) > 0, f"Returned empty list for {func_name}"

        print(f"[PASS] {func_name} at {datetime.now()}")

    except Exception as e:
        print(f"[FAIL] {func_name} - Error: {e}")
        pytest.fail(f"Test failed for {func_name}: {e}")
