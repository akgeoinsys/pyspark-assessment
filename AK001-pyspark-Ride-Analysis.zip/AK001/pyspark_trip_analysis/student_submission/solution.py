# solution.py

import os 
##import all required libaries 

def load_data(spark: SparkSession, trips_path: str, drivers_path: str) -> (DataFrame, DataFrame):
    #define schema here for both dataframes 
    
    trips_df = spark.read.csv(f"file://{os.path.abspath(trips_path)}", header=True, schema=trips_schema)
    drivers_df = spark.read.csv(f"file://{os.path.abspath(drivers_path)}", header=True, schema=drivers_schema)

    return trips_df, drivers_df


def clean_trips(trips_df: DataFrame) -> DataFrame:
   

def convert_unix_to_date(trips_df: DataFrame) -> DataFrame:
   

def calculate_avg_fare_per_km(trips_df: DataFrame) -> DataFrame:
    

def join_with_driver(trips_df: DataFrame, drivers_df: DataFrame) -> DataFrame:
   


def top_n_earning_drivers(joined_df: DataFrame, n: int) -> DataFrame:
   
