import pytest
import ast
import student_submission.solution as sol
from pyspark.sql import SparkSession
import os

# Root paths
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_PATH = os.path.join(ROOT_DIR, "test_report.log")

# Logging test results
def log_result(func_name, status):
    try:
        with open(LOG_PATH, "a") as f:
            f.write(f"[{status.upper()}] {func_name}\n")
    except Exception as e:
        print(f"Logging failed: {e}")

# Load test config
def load_config(path="tests/test_config.json"):
    import json
    with open(path) as f:
        return json.load(f)

# Spark session fixture
@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder \
        .master("local[*]") \
        .appName("RideSharingTest") \
        .config("spark.hadoop.fs.defaultFS", "file:///") \
        .getOrCreate()

# Base data loading fixture
@pytest.fixture(scope="module")
def df_pair(spark):
    return sol.load_data(spark, "data/trips.csv", "data/drivers.csv")

# Anti-cheat pass detector
def check_no_pass(func_name):
    tree = ast.parse(open("student_submission/solution.py").read())
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            for sub in ast.walk(node):
                if isinstance(sub, ast.Pass):
                    raise AssertionError(f"Anti-cheat violation: 'pass' in {func_name}()")

# Parametrize test cases from config
def pytest_generate_tests(metafunc):
    if "test_case" in metafunc.fixturenames:
        config = load_config()
        metafunc.parametrize("test_case", config)

# Main test runner
def test_from_config(test_case, spark, df_pair):
    func_name = test_case["function"]
    status = "pass"

    try:
        check_no_pass(func_name)

        df1, df2 = df_pair

        # --- Function dependency chain ---
        if func_name == "load_data":
            result = sol.load_data(spark, "data/trips.csv", "data/drivers.csv")

        elif func_name == "clean_trips":
            result = sol.clean_trips(df1)

        elif func_name == "convert_unix_to_date":
            clean = sol.clean_trips(df1)
            result = sol.convert_unix_to_date(clean)

        elif func_name == "calculate_avg_fare_per_km":
            clean = sol.clean_trips(df1)
            converted = sol.convert_unix_to_date(clean)
            result = sol.calculate_avg_fare_per_km(converted)

        elif func_name == "join_with_driver":
            clean = sol.clean_trips(df1)
            converted = sol.convert_unix_to_date(clean)
            calculated = sol.calculate_avg_fare_per_km(converted)
            result = sol.join_with_driver(calculated, df2)

        elif func_name == "top_n_earning_drivers":
            clean = sol.clean_trips(df1)
            converted = sol.convert_unix_to_date(clean)
            calculated = sol.calculate_avg_fare_per_km(converted)
            joined = sol.join_with_driver(calculated, df2)
            result = sol.top_n_earning_drivers(joined, test_case["args"][1])

        else:
            raise ValueError(f"Unhandled function in config: {func_name}")

        # --- Output validation ---
        if test_case["expected"] == "DataFrame":
            assert result.count() >= 0
        elif test_case["expected"] == "tuple":
            assert isinstance(result, tuple) and len(result) == 2
        elif test_case["expected"] == "list":
            assert isinstance(result, list)
        elif test_case["expected"] == "dict":
            assert isinstance(result, dict)
        elif test_case["expected"] == "int":
            assert isinstance(result, int)

    except Exception:
        status = "fail"
        raise
    finally:
        log_result(func_name, status)
        print(f"[{status.upper()}] {func_name}")

