python3 -m venv venv
source venv/bin/activate
pip install pyspark==3.1.3
pip install pytest
pip install --upgrade pip 
